/*******************************************************************************
* File Name: PwmY.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PwmY_ALIASES_H) /* Pins PwmY_ALIASES_H */
#define CY_PINS_PwmY_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define PwmY_0			(PwmY__0__PC)
#define PwmY_0_INTR	((uint16)((uint16)0x0001u << PwmY__0__SHIFT))

#define PwmY_INTR_ALL	 ((uint16)(PwmY_0_INTR))

#endif /* End Pins PwmY_ALIASES_H */


/* [] END OF FILE */
